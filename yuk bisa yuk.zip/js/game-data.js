const games = {

mlbb:{
title:"Mobile Legends",
publisher:"Moonton",
image:"../assets/games/mlbb.webp",

nominals:[
{
    nama:"5 Diamond",
    harga:1784
},
{
    nama:"12 Diamond",
    harga:2784
},
{
    nama:"19 Diamond",
    harga:3784
},
{
    nama:"28 Diamond",
    harga:4784
},
{
    nama:"36 Diamond",
    harga:5784
}
]

},

ff:{
title:"Free Fire",
publisher:"Garena",
image:"../assets/games/freefire.webp",

nominals:[
{
    nama:"5 Diamond",
    harga:1784
},
{
    nama:"12 Diamond",
    harga:2784
},
{
    nama:"19 Diamond",
    harga:3784
},
{
    nama:"28 Diamond",
    harga:4784
},
{
    nama:"36 Diamond",
    harga:5784
}
]

},

hok:{
title:"Honor of Kings",
publisher:"Level Infinite",
image:"../assets/games/hok.webp",

nominals:[
{
    nama:"5 Diamond",
    harga:1784
},
{
    nama:"12 Diamond",
    harga:2784
},
{
    nama:"19 Diamond",
    harga:3784
},
{
    nama:"28 Diamond",
    harga:4784
},
{
    nama:"36 Diamond",
    harga:5784
}
]

}

};
const params=new URLSearchParams(location.search);

const key=params.get("game")||"mlbb";

const game=games[key];

document.getElementById("gameTitle").textContent=game.title;

document.getElementById("gamePublisher").textContent=game.publisher;

document.getElementById("gameImage").src=game.image;

document.getElementById("summaryGame").textContent=game.title;

const nominalGrid=document.getElementById("nominalGrid");

nominalGrid.innerHTML="";

game.nominals.forEach(item=>{

nominalGrid.innerHTML+=`
<div class="nominal-card"
data-name="${item.nama}"
data-price="${item.harga}">

<h3>${item.nama}</h3>

<p>Rp ${item.harga.toLocaleString("id-ID")}</p>

</div>
`;

});

const nominalCards=document.querySelectorAll(".nominal-card");

nominalCards.forEach(card=>{

card.onclick=()=>{

nominalCards.forEach(c=>c.classList.remove("active"));

card.classList.add("active");

document.getElementById("summaryNominal").textContent=
card.dataset.name;

document.getElementById("summaryPrice").textContent=
"Rp "+Number(card.dataset.price).toLocaleString("id-ID");

};

});