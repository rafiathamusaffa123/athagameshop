const auth = firebase.auth();

const loginForm = document.getElementById("loginForm");

if (loginForm) {

    loginForm.addEventListener("submit", (e) => {

        e.preventDefault();

        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value;

        if (email === "" || password === "") {
            alert("Email dan Password harus diisi.");
            return;
        }

        auth.signInWithEmailAndPassword(email, password)

        .then(() => {

            alert("Login berhasil.");

            window.location.href = "../index.html";

        })

        .catch((error) => {

            alert("Login gagal : " + error.message);

        });

    });

}