const nominalCard = document.querySelectorAll(".nominal-card");

nominalCard.forEach(card=>{

    card.addEventListener("click",()=>{

        nominalCard.forEach(item=>item.classList.remove("active"));

        card.classList.add("active");

    });

});

const paymentCard=document.querySelectorAll(".payment-card");

paymentCard.forEach(card=>{

    card.addEventListener("click",()=>{

        paymentCard.forEach(item=>item.classList.remove("active"));

        card.classList.add("active");

    });

});

const buyBtn = document.querySelector(".buy-btn");

if (buyBtn) {

    buyBtn.addEventListener("click", () => {

        const userId = document.getElementById("userId").value.trim();

        const whatsapp = document.getElementById("whatsapp").value.trim();

        const nominal = document.querySelector(".nominal-card.active");

        const payment = document.querySelector(".payment-card.active");

        if (userId === "") {

            alert("Masukkan User ID terlebih dahulu.");

            return;

        }

        if (!nominal) {

            alert("Pilih nominal terlebih dahulu.");

            return;

        }

        if (!payment) {

            alert("Pilih metode pembayaran.");

            return;

        }

        if (whatsapp === "") {

            alert("Masukkan nomor WhatsApp.");

            return;

        }

        alert("Data lengkap. Tahap berikutnya akan masuk ke checkout.");

    });

}

const buyBtn=document.getElementById("buyBtn");

if(buyBtn){

buyBtn.onclick=()=>{

const game=document.getElementById("summaryGame").textContent;
const nominal=document.getElementById("summaryNominal").textContent;
const payment=document.getElementById("summaryPayment").textContent;
const total=document.getElementById("summaryPrice").textContent;

const userId=document.getElementById("userId").value;
const zoneId=document.getElementById("zoneId").value;
const wa=document.getElementById("whatsapp").value;

if(nominal=="Belum dipilih"){
alert("Pilih nominal.");
return;
}

if(payment=="Belum dipilih"){
alert("Pilih metode pembayaran.");
return;
}

if(userId==""){
alert("Masukkan User ID.");
return;
}

if(wa==""){
alert("Masukkan Nomor WhatsApp.");
return;
}

const now=new Date();

const tanggal=now.toLocaleDateString("id-ID");

const jam=now.toLocaleTimeString("id-ID");

const antrian=Math.floor(Math.random()*9000+1000);

const kode="ATHA-"+now.getFullYear()+
String(now.getMonth()+1).padStart(2,"0")+
String(now.getDate()).padStart(2,"0")+
"-"+antrian;

const pesan=`🛒 ORDER BARU ATHA STORE

━━━━━━━━━━━━━━

Kode Pesanan :
${kode}

No Antrian :
#${antrian}

Tanggal :
${tanggal}

Jam :
${jam}

Status :
🟡 PENDING

━━━━━━━━━━━━━━

Game :
${game}

User ID :
${userId}

Zone ID :
${zoneId}

Nominal :
${nominal}

Pembayaran :
${payment}

Total :
${total}

━━━━━━━━━━━━━━

Nomor Pembeli :
${wa}

Mohon kirim nomor pembayaran.
`;

window.open(
"https://wa.me/6281910545769?text="+encodeURIComponent(pesan),
"_blank"
);

};

}