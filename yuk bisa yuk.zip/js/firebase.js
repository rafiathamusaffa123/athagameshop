// Firebase Config

const firebaseConfig = {
  apiKey: "AIzaSyCUJQmSZl8WaaakNsD38nY6ZwfCuvw6AGc",
  authDomain: "atha-store.firebaseapp.com",
  projectId: "atha-store",
  storageBucket: "atha-store.firebasestorage.app",
  messagingSenderId: "495893673405",
  appId: "1:495893673405:web:3c6d53902b24b3e1a78ed4"
};

firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const db = firebase.firestore();