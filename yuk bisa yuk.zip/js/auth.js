// REGISTER
const registerForm = document.getElementById("registerForm");

if (registerForm) {
    registerForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const nama = document.getElementById("nama").value;
        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;

        try {
            const userCredential = await auth.createUserWithEmailAndPassword(email, password);

            const uid = userCredential.user.uid;

            await db.collection("users").doc(uid).set({
                nama: nama,
                email: email,
                role: "user",
                saldo: 0,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            alert("Register berhasil!");
            location.href = "login.html";

        } catch (err) {
            alert(err.message);
        }
    });
}