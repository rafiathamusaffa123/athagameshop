alert("register.js berhasil dimuat");
const auth = firebase.auth();

const registerForm = document.getElementById("registerForm");

registerForm.addEventListener("submit", function(e){

    e.preventDefault();

    alert("Submit berhasil dicegah");

});

if (registerForm) {

    registerForm.addEventListener("submit", (e) => {

        e.preventDefault();

        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value;
        const confirmPassword = document.getElementById("confirmPassword").value;

        if (password !== confirmPassword) {
            alert("Password tidak sama.");
            return;
        }

        auth.createUserWithEmailAndPassword(email, password)
            .then(() => {
                alert("Akun berhasil dibuat.");
                window.location.href = "login.html";
            })
            .catch((error) => {
                alert(error.message);
            });

    });

}